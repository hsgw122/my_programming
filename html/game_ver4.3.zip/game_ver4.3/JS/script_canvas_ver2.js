/// <reference path="createJS.js" />

//ポップアップとボタン

//データをやり取りするにはPHPが必要

// 変数ゾーン //
{
//デバッグモードか
//var debug = true;
var debug = false;
console.log("DEBUG : "+debug);

//ゲームのステージ
var game_stage;
//キャンバスの大きさ
var canvasWidth;
var canvasHeight;

//マトリックスのリスト
var matrix_list = [[20,3,1,0,0,1,1,1]];
const en = 9;

//マトリックスリストの長さ
var list_length = matrix_list.length;
//現在のラウンド
var round = 0;
//現在のマトリックス
var choice_matrix = matrix_list[round];
//マトリックスに配置されている数値、ペイオフ値
var a = choice_matrix[0];
var b = choice_matrix[1];
var c = choice_matrix[2];
var d = choice_matrix[3];
var e = choice_matrix[4];
var f = choice_matrix[5];
var g = choice_matrix[6];
var h = choice_matrix[7];

//マトリックスを初期化する。m_sizeで範囲を指定する
function mat(m_size){
    var staghunt = [];
    var pd = [];
    for (var a = 0;a < m_size;a++){
      for (var b = 0;b < m_size;b++){
        for (var c = 0;c < m_size;c++){
          for (var d = 0;d < m_size;d++){
            for (var e = 0;e < m_size;e++){
              for (var f = 0;f < m_size;f++){
                for (var g = 0;g < m_size;g++){
                  for (var h = 0;h < m_size;h++){
                    //stag hunt
                    if (a == b && g == h && c == f && d == e && a > d && d >= g && g > c){
                      //配列にプッシュ
                      staghunt.push([b,a,d,c,f,e,h,g,"staghunt"]);
                    }else if (a == b && g == h && c == f && d == e && d > a && a > g && g > c){
                      //配列にプッシュ
                      pd.push([b,a,d,c,f,e,h,g,"PD"]);
                    }
            
                  }
                }
              }
            }
          }
        }
      }
    }
    var matrix_list = [];
    //結合
    matrix_list = matrix_list.concat([[7,5,7,5,7,5,7,5,"def"]]);
    matrix_list = matrix_list.concat(staghunt);
    matrix_list = matrix_list.concat(pd);
    matrix_list.push([en,en,en,en,en,en,en,en,"End"]);
    console.log("matrilx list length : "+matrix_list.length);

    choice_matrix = matrix_list[0];
    a = choice_matrix[0];
    b = choice_matrix[1];
    c = choice_matrix[2];
    d = choice_matrix[3];
    e = choice_matrix[4];
    f = choice_matrix[5];
    g = choice_matrix[6];
    h = choice_matrix[7];

    return matrix_list;
  
}

//数値を初期化
function resetMatrixValue() {
    //現在のマトリックス
    choice_matrix = matrix_list[round];
    //マトリックスに配置されている数値、ペイオフ値
    a = choice_matrix[0];
    b = choice_matrix[1];
    c = choice_matrix[2];
    d = choice_matrix[3];
    e = choice_matrix[4];
    f = choice_matrix[5];
    g = choice_matrix[6];
    h = choice_matrix[7];
    
}
}

//重み
{
    //コンピュータの重み
    var self_weight  = 1;
    var other_weight = 0;
    /*
    var self_weight  = Math.random() * 2.0 - 1.0;
    var other_weight = Math.random() * 2.0 - 1.0;
    */
    console.log("self : "+self_weight);
    console.log("other : "+other_weight);
}

//得点、スコア
var cpu_score = 0;
var player_score = 0;

//色
var cpu_color = "rgba(100,200,200,0.8)";
var player_color = "rgba(200,200,100,0.8)";


// 関数ゾーン //

//ロード時に、initを実行
window.addEventListener("load", init);

//初期化関数、init、最初に1回実行される
function init() {

    //画像をプリロード
    imagePreLoad();
    //マトリックスをセット、長さも取得
    matrix_list = mat(4);
    list_length = matrix_list.length;
    resetMatrixValue();
    //キャンバス情報を取得、キャンバス扱いに
    const gameCanvas = /** @type {HTMLCanvasElement} */ (document.getElementById("myCanvasBottom"));
    //横、縦の大きさも取得
    canvasWidth = gameCanvas.width;
    canvasHeight = gameCanvas.height;
    //ステージを取得
    game_stage = new createjs.Stage("myCanvasBottom");


    //変数初期化
    cardParametaInit();


    //ゲームコントロールのclass
    var game = new GameControl();

    //準備ができたら思考開始
    AI_brain.think();
    
    
    //ウィンドウのタイミングに合わせる
    createjs.Ticker.timingMode = createjs.Ticker.RAF;

    // 自動的に画面更新させます。
    createjs.Ticker.addEventListener("tick", game_stage);

}

//画像をプリロードする
function imagePreLoad() {

    //画像のロード関数
    function imageLoad(Image,ImageSrc) {
        try {
            Image.src = ImageSrc;
            Image.onload = () => {
                console.log("load : complete  : " + String(ImageSrc));
            }
        } catch(e) {
            console.log(e);
        }

    }

    //imageLoad(deer_image,"./images/deer.png");
    //imageLoad(think_image,"./images/fukidashi02.png");
    //imageLoad(vote_image,"./images/fukidashi14.png");
    
}

// =================== 正規分布 連続 ===================
function xRandomNormal(average, deviation) {
    var z01 = 0;                  // 標準正規分布（０，１）に従う乱数
    for (var i=1; i<=12; i++) {   // 中心極限定理により１２個の一様乱数は正規分布になる
        z01 = z01 + Math.random();
    }
    z01 = z01 - 6;
    return (average + z01) + (deviation * z01);
}

// =================== 正規分布（上下限） 連続 ===================
// 極端な値にならないように、最小値と最大値を設ける
// 通常の正規分布を行い、範囲を逸脱したときには、再度計算を行う
function xRandomNormalMinmax(xmin, xmax, average, deviation) {
    var ok = 0;       // 範囲内なら１、範囲外なら０
    while (ok==0) {
        var z01 = 0;                  // 標準正規分布（０，１）に従う乱数
        for (var i=1; i<=12; i++) {   // 中心極限定理により１２個の一様乱数は正規分布になる
            z01 =z01 + Math.random();
        }
        z01 = z01 - 6;
        var x =  (average + z01) + (deviation * z01);
        if ( (x >= xmin) && (x <= xmax) ) ok = 1;
    }
    return x;
}

// クラスゾーン //

//AgentBrainのプロパティ
{
    //思考中フラグ
    var agent_thinking_f = false;
    //選択フラグ、true:C  false:D
    var agent_C_choiced = false;
    //agentが結果を出したか
    var agent_choiced_f = false;
}

//エージェントの思考のclass
class AgentBrain {

    constructor(self_W=self_weight,other_W=other_weight,wait_time=5){
        //重み
        this.self_W = self_W;
        this.other_W = other_W;
        //待ち時間
        this.wait_time = wait_time;

        //console.log(createjs.Ticker.RAF);

        //思考開始
        //this.think(wait_time);

    }

    //思考関数
    think(wait=this.wait_time) {
        resetMatrixValue();

        agent_thinking_f = true;
        agent_choiced_f = false;
        console.log(choice_matrix);
        var result =  ((a * this.other_W + b * this.self_W) / 2
                    + (c * this.other_W + d * this.self_W) / 2)
                    - ((e * this.other_W + f * this.self_W) / 2
                    + (g * this.other_W + h * this.self_W) / 2);
        console.log(result);
        if(result>0){
            console.log("C");
            agent_C_choiced = true;
        }else if(result<0){
            agent_C_choiced = false;
            console.log("D");
        }else{
            var cho_rand = xRandomNormal(0,1);
            console.log(cho_rand);
            //0の時はランダム
            if(cho_rand>=0){
                agent_C_choiced = true;
                console.log("C");
            }else{
                agent_C_choiced = false;
                console.log("D");
            }
        }

        //乱数時間
        var random = xRandomNormal(wait,0.5);
        var waiting_time = random;
        createjs.Ticker.addEventListener("tick",thinking);
        function thinking() {
            waiting_time -= 1/60;
            if(waiting_time<0){
                createjs.Ticker.removeEventListener("tick",thinking);
                console.log("thinking over: "+random);
                agent_thinking_f = false;

            }
        }
    }
    
}

var AI_brain = new AgentBrain();

//Agentの見た目class
class AgentLooks extends createjs.Container {

    constructor(){
        super();

        game_stage.addChild(this);

        var flag_1 = false;
        var flag_2 = false;
        var flag_3 = false;
        var flag_4 = false;

        //通常状態の画像
        var image_default = new Image();
        image_default.src = "./images/agent_default.png";
        var bmp_default = new createjs.Bitmap(image_default);
        this.addChild(bmp_default);
        image_default.onload = () => {
            //var bmp_default = new createjs.Bitmap(image_default);
            //this.addChild(bmp_default);
            bmp_default.visible = true;

            flag_1 = true;
        }

        //考え中状態の画像
        var image_think = new Image();
        image_think.src = "./images/agent_think.png";
        var bmp_think = new createjs.Bitmap(image_think);
        this.addChild(bmp_think);
        image_think.onload = () => {
            //var bmp_think = new createjs.Bitmap(image_think);
            //this.addChild(bmp_think);
            bmp_think.visible = false;

            flag_2 = true;
        }

        //Cを選んだ状態の画像
        var image_choice_C = new Image();
        image_choice_C.src = "./images/agent_choice_C.png";
        var bmp_choice_C = new createjs.Bitmap(image_choice_C);
        this.addChild(bmp_choice_C);
        image_choice_C.onload = () => {
            //var bmp_choice_C = new createjs.Bitmap(image_choice_C);
            //this.addChild(bmp_choice_C);
            bmp_choice_C.visible = false;

            flag_3 = true;
        }

        //Dを選んだ状態の画像
        var image_choice_D = new Image();
        image_choice_D.src = "./images/agent_choice_D.png";
        var bmp_choice_D = new createjs.Bitmap(image_choice_D);
        this.addChild(bmp_choice_D);
        image_choice_D.onload = () => {
            //var bmp_choice_D = new createjs.Bitmap(image_choice_D);
            //this.addChild(bmp_choice_D);
            bmp_choice_D.visible = false;

            flag_4 = true;
        }

        //全部読み込んだかチェック
        createjs.Ticker.addEventListener("tick",watchDog_loadImages);
        function watchDog_loadImages() {
            if(flag_1 && flag_2 && flag_3 && flag_4){
                createjs.Ticker.removeEventListener("tick",watchDog_loadImages);
                createjs.Ticker.addEventListener("tick",watchDog_agentLooks);
            }
            
        }

        function watchDog_agentLooks() {
            //agentが考え中か
            if(agent_thinking_f){
                bmp_default.visible = false;
                bmp_think.visible = true;
                bmp_choice_C.visible = false;
                bmp_choice_D.visible = false;
            }else{
                bmp_default.visible = true;
                bmp_think.visible = false;
                bmp_choice_C.visible = false;
                bmp_choice_D.visible = false;
            }

            //agentが結果を出したか
            if(agent_choiced_f){
                bmp_default.visible = false;
                bmp_think.visible = false;
                if(agent_C_choiced){
                    bmp_choice_C.visible = true;
                    bmp_choice_D.visible = false;
                }else{
                    bmp_choice_C.visible = false;
                    bmp_choice_D.visible = true;
                }
            }
            
        }

    }
}

//プレイヤーの状態のプロパティ
{
    //選んだフラグ
    var player_choiced_f = false;

    //ボタンのフラグ、cpuと同じ
    var C_button_flag = false;
    //var D_button_flag = false;
}


//GameControlのプロパティ
{
    var button_C_fillColor = "rgba(255,100,100,1.0)";
    var button_D_fillColor = "rgba(100,100,255,1.0)";

    //カードの位置、計算後に出る
    var card_x;
    var card_y;

    //マトリックスの位置
    var matrix_x = 60;
    var matrix_y = 60;

}

//ゲームコントロールclass
//場所をコントロールする
class GameControl {

    constructor(){

        //エージェントの見た目class
        var agent_looks = new AgentLooks();
        agent_looks.x = canvasWidth - 210;
        agent_looks.y = canvasHeight / 2 -150;


        var height_y = canvasHeight * 0.5;;
        

        //playerの獲得したスコアのボックス
        var player_reward_box = new RewardBox("YOU","rgba(250,250,200,0.8)");
        player_reward_box.x = rb_wid;
        player_reward_box.y = height_y;
        player_reward_box.visible = false;

        //Cのカードclass
        var C_card = new ChoiceCard("C");
        C_card.x = player_reward_box.x + rb_wid/2 + card_wid/2;
        C_card.y = height_y;
        C_card.setScoreBorad(a,b,e,f);
        
        //Dのカードclass
        var D_card = new ChoiceCard("D");
        D_card.x = C_card.x;
        D_card.y = height_y;
        D_card.setScoreBorad(c,d,g,h);

        card_x = C_card.x;
        card_y = C_card.y;

        //cpuの獲得したスコアのボックス
        var cpu_reward_box = new RewardBox("CPU","rgba(200,250,250,0.8)");
        cpu_reward_box.x = C_card.x + card_wid/2 + rb_wid/2;
        cpu_reward_box.y = player_reward_box.y;
        cpu_reward_box.visible = false;


        //得られるスコアの表示
        function setReward(p_over=a,c_over=b,p_down=e,c_down=f,player_total=player_score,cpu_total=cpu_score) {
            player_reward_box.setTotalReward(player_total);
            player_reward_box.setWillGetReward(p_over,p_down);
            cpu_reward_box.setTotalReward(cpu_total);
            cpu_reward_box.setWillGetReward(c_over,c_down);
        }

        //ラウンドテキスト
        var round_Text = new RoundText();
        round_Text.x = canvasWidth - 100;
        round_Text.y = 100;

        //次のラウンドへ
        function nextRound() {
            //モーションを起動
            //カードのモーション
            createjs.Tween.get(C_card)
                .to({x: canvasWidth*1.5 },100)
                .to({x: card_x, y: -100 },10)
                .to({x: card_x, y: card_y, scaleX: 1.0, scaleY: 1.0 },500,createjs.Ease.cubicIn);
            createjs.Tween.get(D_card)
                .to({x: canvasWidth*1.5 },100)
                .to({x: card_x, y: -100 },10)
                .to({x: card_x, y: card_y, scaleX: 1.0, scaleY: 1.0 },500,createjs.Ease.cubicIn);

            //マトリックスのモーション
            createjs.Tween.get(mate)
                .to({x: -100 },100)
                .to({x: -200, y: matrix_y },10)
                .to({x: matrix_x, y: matrix_y, scaleX: 1.0/matrix_scale, scaleY: 1.0/matrix_scale },500,createjs.Ease.cubicIn);


            //ボタンを見えるようにする
            C_button.visible = true;
            D_button.visible = true;

            //カードのテキストをデフォルトに
            C_card.switchText();
            D_card.switchText();

            //マトリックスのCPUボタンを復活
            mate.cpuButton_gray(true,true);

            round += 1;
            if(round >= list_length){
                round = 0;
            }

            //数値を更新
            resetMatrixValue();

            //AIに思考させる
            AI_brain.think();

            C_card.setScoreBorad(a,b,e,f);
            D_card.setScoreBorad(c,d,g,h);

            if(C_button_flag){
                setReward(a,b,e,f);
                mate.C_kirakira();
            }
            if(!C_button_flag){
                setReward(c,d,g,h);
                mate.D_kirakira();
            }

            mate.setValue();
            round_Text.setRound();

            //プレイヤーの選択権を回復させる
            player_choiced_f = false;
            
        }

        //エージェントを監視する関数
        function checkingAgentThinking() {
            //カードのテキストを、選ばれたに変更
            C_card.switchText(false);
            D_card.switchText(false);

            //エージェントが考えているか
            createjs.Ticker.addEventListener("tick",watchDog_agentThink);
            function watchDog_agentThink() {
                //エージェントが考えるのを終えたら
                if(!agent_thinking_f){
                    createjs.Ticker.removeEventListener("tick",watchDog_agentThink);

                    //数秒の間を開ける
                    var connectTime = 3 * 60;
                    createjs.Ticker.addEventListener("tick",waitingConnect);

                    //モーションを起動
                    //カードのモーション
                    createjs.Tween.get(C_card)//ターゲット指定
                        .to({x: matrix_x+30, y: matrix_y, scaleX: 0.3, scaleY: 0.3 },2000);
                    createjs.Tween.get(D_card)//ターゲット指定
                        .to({x: matrix_x+30, y: matrix_y, scaleX: 0.3, scaleY: 0.3 },2000);

                    //マトリックスのモーション
                    createjs.Tween.get(mate)
                        .to({x: card_x, y: card_y, scaleX: 1.0, scaleY: 1.0 },2000);


                    function waitingConnect() {
                        connectTime -= 1;

                        if(connectTime<0){
                            createjs.Ticker.removeEventListener("tick",waitingConnect);

                            
                            agent_choiced_f = true;

                            //カプセルの表示をエージェントに合わせる
                            C_card.capsuleVisible(false,agent_C_choiced);
                            D_card.capsuleVisible(false,agent_C_choiced);

                            //マトリックスの表示をエージェントに合わせる
                            mate.cpu_kirakira(agent_C_choiced);
                            mate.cpuButton_gray(agent_C_choiced);

                            //獲得できる点数の箱を表示、他は非表示
                            cpu_reward_box.gotWillVisible(false,agent_C_choiced);
                            player_reward_box.gotWillVisible(false,agent_C_choiced);

                            //説明テキストの表示、制御
                            Ret.switchText();
                            Ret.visible = true;
                            Ret.movingThis(true);

                            createjs.Ticker.addEventListener("tick",resultOpen);
                            //結果を表示する関数
                            var result_time = 2 * 60;
                            function resultOpen() {
                                result_time -= 1;
                                if(result_time<0){
                                    
                                    createjs.Ticker.removeEventListener("tick",resultOpen);
                                    /*
                                    C_card.capsuleVisible();
                                    D_card.capsuleVisible();
                                    mate.stop_kirakira();
                                    cpu_reward_box.gotWillVisible();
                                    player_reward_box.gotWillVisible();*/
                                    //nextRound();

                                    next_button.visible = true;
                                }
                        
                            }
                        }
                    }

                }
                
            }
            
        }

        //Cのボタンclass
        var C_button = new ChoiceButton("C","rgba(250,250,250,1.0)",button_C_fillColor);
        C_button.x = C_card.x - button_wid * 0.75;
        C_button.y = canvasHeight - button_hei*0.7;
        
        //Cボタンクリックとフラグを関連付ける
        C_button.addEventListener("click",function() {
            //プレイヤーが選んでいないなら
            if(!player_choiced_f){
                player_choiced_f = true;

                C_button_flag = true;
                console.log(C_button_flag);
                //mate.stop_kirakira();
                //D_button_flag = false;
                D_button.visible = false;

                player_score += a;
                cpu_score += b;
                checkingAgentThinking();
            }

        });
        //Cボタンのマウスオーバー
        C_button.addEventListener("mouseover",function() {
            //プレイヤーが選んでないなら
            if(!player_choiced_f){
                C_card.sizingThis(0.05);
                D_card.sizingZero();
                //D_card.sizingThis(-0.2);
    
                mate.C_kirakira();
    
                setReward();
            }
            
        });
        
        //Dのボタンclass
        var D_button = new ChoiceButton("D","rgba(250,250,250,1.0)",button_D_fillColor);
        D_button.x = C_button.x + button_wid * 1.5;
        D_button.y = C_button.y;
        
        //Dボタンクリックとフラグを関連付ける
        D_button.addEventListener("click",function() {
            //プレイヤーが選んでいないなら
            if(!player_choiced_f){
                player_choiced_f = true;
            
                C_button_flag = false;
                console.log(C_button_flag);
                //mate.stop_kirakira();
                //C_button_flag = false;
                C_button.visible = false;
            
                player_score += c;
                cpu_score += d;
                checkingAgentThinking();
            }
/*
            D_button_flag = true;

            console.log(D_button_flag);
            mate.stop_kirakira();

            C_button_flag = false;

            player_score += c;
            cpu_score += d;
            nextRound();
            */
        });
        //Dボタンのマウスオーバー
        D_button.addEventListener("mouseover",function() {
            if(!player_choiced_f){
                D_card.sizingThis(0.05);
                C_card.sizingZero();
                //C_card.sizingThis(-0.2);
                mate.D_kirakira();
    
                setReward(c,d,g,h);
            }
            
        });

        //次のラウンドへ行くボタン
        var next_button = new ChoiceButton("Next.","black","green");
        next_button.x = canvasWidth-button_wid;
        next_button.y = canvasHeight-button_hei;
        next_button.visible = false;
        next_button.on("click",function(){
            //自分を見えなくする
            next_button.visible = false;
            //説明テキストを非表示に
            Ret.visible = false;
            Ret.movingThis(false);
            //次のラウンドへ
            C_card.capsuleVisible();
            D_card.capsuleVisible();
            mate.stop_kirakira();
            cpu_reward_box.gotWillVisible();
            player_reward_box.gotWillVisible();
            nextRound();
        });

        //ステージのマウスオーバーをオンにする
        game_stage.enableMouseOver();

        //マトリックス
        var mate = new MatrixBox();
        mate.x = matrix_x;
        mate.y = matrix_y;
        mate.setValue();

        //手に入れた得点の説明テキスト
        var Ret = new RewardText();
        Ret.x = Ret_x;
        Ret.y = Ret_y;
        Ret.visible = false;

    }

}

//説明テキストのプロパティ
{
    //自分の画面上の位置
    var Ret_x = 200;
    var Ret_y = 50;


    var Ret_text_you = "You chose";
    var Ret_text_cpu = "Counterpart chose";
    var Ret_text_get = " , and got ";
    var Ret_text_non = " , but no point.";

    var Ret_text_base_fontSize = 20;
    var Ret_text_base_font = String(Ret_text_base_fontSize)+"px fantasy";

    var Ret_text_appeal_fontSize = 30;
    var Ret_text_appeal_font = String(Ret_text_appeal_fontSize)+"px fantasy";

    var Ret_text_fillColor = "black";

    var Ret_text_you_y = 0;
    var Ret_text_cpu_y = 50;

}

//手に入れた得点の説明テキストclass
class RewardText extends createjs.Container {
    cpu_text_chose;
    you_text_got;
    cpu_text_chose;
    cpu_text_got;


    constructor(){
        super();

        this.you_text_chose = "def";
        this.you_text_got = "def";
        this.cpu_text_chose = "def";
        this.cpu_text_got = "def";

        game_stage.addChild(this);

        //テキストを作る関数
        function makeText(text,font,color=player_color){
            var obj = new createjs.Text();
            obj.text = text;
            obj.font = font;
            obj.color = color;
            obj.textAlign = "left";
            obj.textBaseline = "bottom";

            return obj;
        }

        //プレイヤーのテキスト
        var youText_chose = makeText(Ret_text_you,Ret_text_base_font,Ret_text_fillColor);
        this.addChild(youText_chose);
        youText_chose.x = 0;
        youText_chose.y = Ret_text_you_y;

        //プレイヤーの選んだ手
        var you_chose = makeText(this.you_text_chose,Ret_text_appeal_font,Ret_text_fillColor);
        this.addChild(you_chose);
        this.you_chose = you_chose;
        you_chose.x = Ret_text_base_fontSize * 0.6 * Ret_text_you.length;
        you_chose.y = youText_chose.y;

        //プレイヤーのテキスト、「そして手に入れたポイントは」
        var youText_got = makeText(Ret_text_get,Ret_text_base_font,Ret_text_fillColor);
        this.addChild(youText_got);
        this.youText_got = youText_got;
        youText_got.x = you_chose.x + Ret_text_appeal_fontSize * 0.5 * this.you_text_chose.length;
        youText_got.y = youText_chose.y;

        //プレイヤーの手に入れたポイント
        var you_got = makeText(this.you_text_got,Ret_text_appeal_font);
        this.addChild(you_got);
        this.you_got = you_got;
        you_got.x = youText_got.x + Ret_text_base_fontSize * 0.4 * Ret_text_get.length;
        you_got.y = youText_chose.y;

        //ドット
        var point_you = makeText(".",Ret_text_base_font,Ret_text_fillColor);
        this.addChild(point_you);
        point_you.x = you_got.x + Ret_text_appeal_fontSize * 0.3 * this.you_text_got.length;
        point_you.y = youText_chose.y;


        //cpのテキスト
        var cpuText_chose = makeText(Ret_text_cpu,Ret_text_base_font,Ret_text_fillColor);
        this.addChild(cpuText_chose);
        cpuText_chose.x = 0;
        cpuText_chose.y = Ret_text_cpu_y;

        //cpの選んだ手
        var cpu_chose = makeText(this.cpu_text_chose,Ret_text_appeal_font,Ret_text_fillColor);
        this.addChild(cpu_chose);
        this.cpu_chose = cpu_chose;
        cpu_chose.x = Ret_text_base_fontSize * 0.5 * Ret_text_cpu.length;
        cpu_chose.y = cpuText_chose.y;

        var cpuText_got = makeText(Ret_text_get,Ret_text_base_font,Ret_text_fillColor);
        this.addChild(cpuText_got);
        this.cpuText_got = cpuText_got;
        cpuText_got.x = cpu_chose.x + Ret_text_appeal_fontSize * 0.5 * this.cpu_text_chose.length;
        cpuText_got.y = cpuText_chose.y;

        //cpの手に入れたポイント
        var cpu_got = makeText(this.cpu_text_got,Ret_text_appeal_font,cpu_color);
        this.addChild(cpu_got);
        this.cpu_got = cpu_got;
        cpu_got.x = cpuText_got.x + Ret_text_base_fontSize * 0.4 * Ret_text_get.length;
        cpu_got.y = cpuText_chose.y;

        //ドット
        var point_cpu = makeText(".",Ret_text_base_font,Ret_text_fillColor);
        this.addChild(point_cpu);
        point_cpu.x = cpu_got.x + Ret_text_appeal_fontSize * 0.3 * this.cpu_text_got.length;
        point_cpu.y = cpuText_chose.y;

        this.switchText();

        this.movingThis(false);

    }

    //動き
    movingThis(in_f=true){
        if(in_f){
            createjs.Tween.get(this)//ターゲット指定
                .to({y: Ret_y},1000);
        }else{
            createjs.Tween.get(this)//ターゲット指定
                .to({y: -200},1000);
        }

    }

    //テキスト入れ替え
    switchText(player_f=C_button_flag,cpu_f=agent_C_choiced){
        //プレイヤーがCを選んでいるなら
        if(player_f){
            this.you_text_chose = "C";
            this.you_chose.color = button_C_fillColor;
            //cpuがCを選んでいるなら
            if(cpu_f){
                this.cpu_text_chose = "C";
                this.cpu_chose.color = button_C_fillColor;

                this.you_text_got = a;
                this.cpu_text_got = b;
            }else{
                //違うなら
                this.cpu_text_chose = "D";
                this.cpu_chose.color = button_D_fillColor;

                this.you_text_got = e;
                this.cpu_text_got = f;
            }
            
        }else{
            //違うなら
            this.you_text_chose = "D";
            this.you_chose.color = button_D_fillColor;
            //cpuがCを選んでいるなら
            if(cpu_f){
                this.cpu_text_chose = "C";
                this.cpu_chose.color = button_C_fillColor;

                this.you_text_got = c;
                this.cpu_text_got = d;
            }else{
                //違うなら
                this.cpu_text_chose = "D";
                this.cpu_chose.color = button_D_fillColor;

                this.you_text_got = g;
                this.cpu_text_got = h;
            }
        }

        this.you_chose.text = this.you_text_chose;
        this.cpu_chose.text =  this.cpu_text_chose;

        //0点なら
        if(this.you_text_got == "0"){
            this.youText_got.text = Ret_text_non;
            this.you_got.text = "";
        }else{
            this.youText_got.text = Ret_text_get;
            this.you_got.text = this.you_text_got;
        }
        //0点なら
        if(this.cpu_text_got == "0"){
            this.cpuText_got.text = Ret_text_non;
            this.cpu_got.text = "";
        }else{
            this.cpuText_got.text = Ret_text_get;
            this.cpu_got.text = this.cpu_text_got;
        }

        //this.you_got.text = this.you_text_got;
        //this.cpu_got.text = this.cpu_text_got;

    }

}


//ラウンド表示のプロパティ
{
    var rt_main_size = 80;
    var rt_sub_size = rt_main_size * 0.4;
}

//ラウンド表示
class RoundText extends createjs.Container {

    constructor(){
        super();

        game_stage.addChild(this);

        //テキスト
        var text = new createjs.Text();
        text.text = String(round+1);
        text.font = String(rt_main_size)+"px fantasy";
        text.color = "red";
        text.textAlign = "center";
        text.textBaseline = "bottom";
        this.addChild(text);
        this.text = text;

        //第、みたいな
        var text_sub = new createjs.Text();
        text_sub.text = "st";
        text_sub.font = String(rt_sub_size)+"px fantasy";
        text_sub.color = "red";
        text_sub.textAlign = "center";
        text_sub.textBaseline = "bottom";
        this.addChild(text_sub);   
        text_sub.x = rt_sub_size * 2;
        this.text_sub = text_sub; 

    }

    setRound() {
        this.text.text = String(round+1);
        this.text_sub.text = this.textCheck(round+1);
    }

    textCheck(value) {
        var tex = "??";
        if(value==1){
            tex = "st";
        }else if(value==2){
            tex = "nd";
        }else if(value==3){
            tex = "rd";
        }else{
            tex = "th";
        }
        return tex;

    }
}


//カードのカプセルと
//得られる得点の表示位置プロパティ
{
    var card_and_reward_over_Y = -90;
    var card_and_reward_down_Y = 90;
}


//カードのプロパティ
{
//カードの位置
var card_x = 0;
var card_y = 0;
//カードのサイズ
var card_wid;
var card_hei;
var card_round;
//カードの色
var card_stroke_size;
var card_stroke_color;
var card_fill_color;
//カードのテキスト
var card_text_fontsize;
var card_text_default;
var card_text_choiced;
var card_text_font;
var card_text_choice_font;
var card_text_color;
var card_text_choice_color;
var card_text_textAlign;
var card_text_textBaseline;
var card_text_x;
var card_text_y;
//カードの報酬のテキスト
var card_youText;
var card_youText_color;
var card_cpuText;
var card_cpuText_color;
var card_Text_fontSize;

//カードのカプセル
var card_capsule_wid;
var card_capsule_hei;
var card_capsule_round;
var card_capsule_C_fillColor = "rgba(240,100,100,0.4)";
var card_capsule_D_fillColor = "rgba(100,100,240,0.4)";
//カードのボックス
var card_box_wid;
var card_box_hei;
var card_box_round;
var card_box_x;
var card_box_player_fillColor;
var card_box_cpu_fillColor;
}

//変数の初期化
function cardParametaInit() {
    //カードのサイズ
    card_wid = canvasWidth * 0.6;
    card_hei = canvasHeight* 0.7;
    card_round = 10;
    //カードの色
    card_stroke_size  = 1;
    card_stroke_color = "rgba(250,250,250,0.1)";
    card_fill_color   = "rgba(250,250,250,0.1)";
    //カードのテキスト
    card_text_fontsize = 25;
    card_text_default = "If you chose : ";
    card_text_choiced = "you chose ";
    card_text_font = String(card_text_fontsize)+"px sans-serif";
    card_text_choice_font = String(card_text_fontsize+10)+"px sans-serif";
    card_text_color = "black";
    card_text_choice_color = "red";
    card_text_textAlign = "center";
    card_text_textBaseline = "bottom";
    card_text_x = 0;
    card_text_y = -card_hei/2;
    //カードの報酬のテキスト
    card_youText = "You will get :";
    card_youText_color = "black";
    card_cpuText = "Counterpart will get :";
    card_cpuText_color = "black";
    card_Text_fontSize = 20;

    //カードのカプセル
    card_capsule_wid = card_wid * 0.9;
    card_capsule_hei = card_hei * 0.3;
    card_capsule_round = 10;
    //card_capsule_C_fillColor = "rgba(240,100,100,0.4)";
    //card_capsule_D_fillColor = "rgba(100,100,240,0.4)";
    //カードのボックス
    card_box_wid = card_capsule_wid * 0.42;
    card_box_hei = card_capsule_hei * 0.7;
    card_box_round = 10;
    card_box_x = card_box_wid * 0.6;
    card_box_player_fillColor = "rgba(255,100,200,0.8)";
    card_box_cpu_fillColor = "rgba(100,100,255,0.8)";
}

var ffff = true;

//カードclass
class ChoiceCard extends createjs.Container {

    //加える分のtext
    constructor(plusText="",card_fillColor=card_fill_color){
        super();

        //自分をステージに追加
        game_stage.addChild(this);

        //カードを表示
        var card = new createjs.Shape();
        card.graphics
            .setStrokeStyle(card_stroke_size)
            .beginStroke(card_stroke_color)
            .beginFill(card_fillColor)
            .drawRoundRect(-card_wid/2,-card_hei/2,card_wid,card_hei,card_round);
        this.addChild(card);


        //カード名を表示、デフォルトの表示名
        var text_default = new createjs.Text("", "", "");
        text_default.text = card_text_default + plusText;
        text_default.font = card_text_font;
        text_default.color = card_text_color;
        //中心にセット
        text_default.x = card_text_x;
        text_default.y = card_text_y;
        text_default.textAlign = card_text_textAlign;
        text_default.textBaseline = card_text_textBaseline;
        //this.addChild(text_default);
        text_default.visible = true;
        this.text_default = text_default;

        //カード名を表示、選ばれた場合に表示するテキスト
        var text_choice = new createjs.Text("", "", "");
        text_choice.text = card_text_choiced + plusText;
        text_choice.font = card_text_choice_font;
        text_choice.color = card_text_choice_color;
        //中心にセット
        text_choice.x = text_default.x;
        text_choice.y = text_default.y;
        text_choice.textAlign = card_text_textAlign;
        text_choice.textBaseline = card_text_textBaseline;
        //this.addChild(text_choice);
        text_choice.visible = false;
        this.text_choice = text_choice;


        //上側

        //上側報酬のリストを表示functionのretrun
        var C_capsule = this.makeCapsule("C",card_capsule_C_fillColor);
        //C_capsule.y = -card_capsule_hei * 0.4;
        C_capsule.y = card_and_reward_over_Y;
        //console.log(card_and_reward_over_Y);
        this.addChild(C_capsule);
        this.C_capsule = C_capsule;

        //プレイヤー　が得られる報酬という説明テキスト
        var yourText = new createjs.Text("", "", "");
        yourText.text = card_youText;
        yourText.font = String(card_Text_fontSize)+"px sans-serif";
        yourText.color = card_youText_color;
        yourText.x = -card_box_wid * 0.6;
        yourText.y = card_and_reward_over_Y - card_capsule_hei * 0.4;
        yourText.textAlign = card_text_textAlign;
        yourText.textBaseline = card_text_textBaseline;
        //this.addChild(yourText);
        //コンピュータが得られる報酬という説明テキスト
        var cpuText = new createjs.Text("", "", "");
        cpuText.text = card_cpuText;
        cpuText.font = String(card_Text_fontSize)+"px sans-serif";
        cpuText.color = card_cpuText_color;
        cpuText.x = +card_box_wid * 0.6;
        cpuText.y = yourText.y;
        cpuText.textAlign = card_text_textAlign;
        cpuText.textBaseline = card_text_textBaseline;
        //this.addChild(cpuText);


        //上か下のカプセルが選ばれるOr
        var ORText = new createjs.Text("", "", "");
        ORText.text = "OR";
        ORText.font = String(30)+"px fantasy";
        ORText.color = "gray";
        ORText.x = 0;
        ORText.y = 15;
        ORText.textAlign = card_text_textAlign;
        ORText.textBaseline = card_text_textBaseline;
        this.addChild(ORText);
        this.ORText = ORText;


        //下側

        //下側報酬のリストを表示functionのretrun
        var D_capsule = this.makeCapsule("D",card_capsule_D_fillColor);
        //D_capsule.y = card_capsule_hei * 0.9;
        D_capsule.y = card_and_reward_down_Y;
        this.addChild(D_capsule);
        this.D_capsule = D_capsule;


        //自分をサイズ0にする
        this.scaleX = 0.0;
        this.scaleY = 0.0;

        //this.sizingThis(0.1);


        //スコアの得点表示
        var score_C_you = new ScoreBorad([1,0,0]);
        score_C_you.x = -card_box_x;
        score_C_you.y = card_box_hei * 0.1;
        C_capsule.addChild(score_C_you);
        this.score_C_you = score_C_you;

        var score_C_cpu = new ScoreBorad([1,1,1]);
        score_C_cpu.x = card_box_x;
        score_C_cpu.y = score_C_you.y;
        C_capsule.addChild(score_C_cpu);
        this.score_C_cpu = score_C_cpu;

        var score_D_you = new ScoreBorad([1,1,1]);
        score_D_you.x = -card_box_x;
        score_D_you.y = score_C_you.y;
        D_capsule.addChild(score_D_you);
        this.score_D_you = score_D_you;

        var score_D_cpu = new ScoreBorad([1,1,1]);
        score_D_cpu.x = card_box_x;
        score_D_cpu.y = score_C_you.y;
        D_capsule.addChild(score_D_cpu);
        this.score_D_cpu = score_D_cpu;

        this.setScoreBorad(a,b,c,d);

    }

    //カプセルの表示変更
    capsuleVisible(default_f=true,C_f=true){
        if(default_f){
            this.C_capsule.visible = true;
            this.ORText.visible = true;
            this.D_capsule.visible = true;
        }else{
            if(C_f){
                this.C_capsule.visible = true;
                this.ORText.visible = false;
                this.D_capsule.visible = false;
            }else{
                this.C_capsule.visible = false;
                this.ORText.visible = false;
                this.D_capsule.visible = true;
            }
        }

    }

    //表示テキストを変更
    switchText(default_f = true){
        if(default_f){
            this.text_default.visible = true;
            this.text_choice.visible  = false;
        }else{
            this.text_default.visible = false;
            this.text_choice.visible  = true;           
        }

    }

    //スコアをセットする
    setScoreBorad(a=7,b=7,c=7,d=7){
        this.score_C_you.setScore(toScoreList(a));
        this.score_C_cpu.setScore(toScoreList(b));
        this.score_D_you.setScore(toScoreList(c));
        this.score_D_cpu.setScore(toScoreList(d));

    }

    //サイズを変更する
    sizingThis(rate = -0.1){
        this.visible = true;
        var listener = this;
        createjs.Ticker.removeEventListener("tick",sizing);
        createjs.Ticker.addEventListener("tick",sizing);
        function sizing() {
            listener.scaleX += rate;
            listener.scaleY += rate;
            if(listener.scaleX > 1){
                listener.scaleX = 1.0;
                listener.scaleY = 1.0;
    
                createjs.Ticker.removeEventListener("tick",sizing);
            }else if(listener.scaleX < 0){
                listener.scaleX = 0.0;
                listener.scaleY = 0.0;
    
                createjs.Ticker.removeEventListener("tick",sizing);
            };
                
        }
    }

    //サイズを0にする
    sizingZero(){
        this.visible = false;
        this.scaleX = 0.0;
        this.scaleY = 0.0;
    }

    //リスナーを加える
    listenerThis(add=true){
        var listener = this;
        if(add == true){
            this.addEventListener("mouseover",handleMouseOver);
            this.addEventListener("mouseout",handleMouseOut);
        }else if(add == false){
            this.removeEventListener("mouseover",handleMouseOver);
            this.removeEventListener("mouseout",handleMouseOut);
        }

        function handleMouseOver() {
            if(ffff){
                listener.scaleX = 1.1;
                listener.scaleY = 1.1;
            }
        }

        function handleMouseOut() {
            listener.scaleX = 1.0;
            listener.scaleY = 1.0;
        }
    }

    //報酬capsuleを1つを作って、capsuleを返す
    makeCapsule(plusText="C",fillColor="gray",strokeColor="rgba(100,100,100,0.1)") {
        //上下に表示するcapsuleのうちの1つ
        var capsule = new createjs.Container();

        //表示するcapsuleくん
        var bg = new createjs.Shape();
        bg.graphics
            .setStrokeStyle(1)
            .beginStroke(strokeColor)
            .beginFill(fillColor)
            .drawRoundRect(-card_capsule_wid/2,-card_capsule_hei/2,card_capsule_wid,card_capsule_hei,card_capsule_round);
        capsule.addChild(bg);

        //自分側の報酬function return
        //var player_box = this.makeBox("rgba(255,100,100,0.8)");
        var player_box = this.makeBox("rgba(250,250,200,0.8)");
        player_box.x = -card_box_x;
        player_box.y = card_box_hei * 0.1;
        capsule.addChild(player_box);

        //相手側の報酬function return
        //var cpu_box = this.makeBox("rgba(100,100,255,0.8)");
        var cpu_box = this.makeBox("rgba(100,250,250,0.8)");
        cpu_box.x = card_box_x;
        cpu_box.y = player_box.y;
        capsule.addChild(cpu_box);

        //中心に置く壁
        var centerBar = new createjs.Shape();
        centerBar.graphics
            .setStrokeStyle(1)
            .beginStroke("gray")
            .beginFill("Black")
            .drawRoundRect(0,-card_capsule_hei*0.4,0,card_capsule_hei*0.8,0);
        capsule.addChild(centerBar);

        //相手が選んだ場合のテキスト
        var choseText = new createjs.Text();
        choseText.text = "If counterpart choose "+plusText+" ...";
        choseText.font = String(card_Text_fontSize*0.8)+"px sans-serif";
        choseText.color = card_youText_color;
        choseText.x = -card_box_wid * 0.7;
        choseText.y = -card_capsule_hei * 0.6;
        choseText.textAlign = card_text_textAlign;
        choseText.textBaseline = card_text_textBaseline;
        capsule.addChild(choseText);

        //得られる報酬に関するテキスト説明
        //プレイヤー　が得られる報酬という説明テキスト
        var yourText = new createjs.Text("", "", "");
        yourText.text = card_youText;
        yourText.font = String(card_Text_fontSize)+"px sans-serif";
        yourText.color = card_youText_color;
        yourText.x = -card_box_wid * 0.6;
        yourText.y = -card_capsule_hei * 0.3;
        yourText.textAlign = card_text_textAlign;
        yourText.textBaseline = card_text_textBaseline;
        capsule.addChild(yourText);
        //コンピュータが得られる報酬という説明テキスト
        var cpuText = new createjs.Text("", "", "");
        cpuText.text = card_cpuText;
        cpuText.font = String(card_Text_fontSize)+"px sans-serif";
        cpuText.color = card_cpuText_color;
        cpuText.x = +card_box_wid * 0.6;
        cpuText.y = yourText.y;
        cpuText.textAlign = card_text_textAlign;
        cpuText.textBaseline = card_text_textBaseline;
        capsule.addChild(cpuText);

        return capsule;

    }

    //報酬を1つ作って返す
    makeBox(fillColor="gray",strokeColor="rgba(100,100,100,0.1)") {
        //右左に表示するボックスのうちの1つ
        var box = new createjs.Container();

        //表示するboxくん
        var bg = new createjs.Shape();
        bg.graphics
            .setStrokeStyle(1)
            .beginStroke(strokeColor)
            .beginFill(fillColor)
            .drawRoundRect(-card_box_wid/2,-card_box_hei/2,card_box_wid,card_box_hei,card_box_round);
        box.addChild(bg);

        return box;

    }
}


//マトリックスのプロパティ
{
    //マトリックスの倍率、大きさ倍
    var matrix_scale = 3;
    var matrix_wid = 100 * matrix_scale;
    var matrix_hei = 60 * matrix_scale;

    var box_wid = matrix_wid / 4;
    var box_hei = matrix_hei / 2;

    //表示テキストのサイズ
    var matrix_fontSize = 10*matrix_scale;
}

//マトリックスのclass
class MatrixBox extends createjs.Container {

    constructor(youColor=player_color,cpuColor=cpu_color){
        super();

        game_stage.addChild(this);

        //マトリックス
        var matrix = new createjs.Shape();
        matrix.graphics
            .setStrokeStyle(1)
            .beginStroke("black")
            .beginFill("gray")
            .drawRect(0,-matrix_hei/2,matrix_wid,matrix_hei);
        //this.addChild(matrix);


        //キラキラ
        function kirakira(box) {
            var rate = 1/60 *0.5;
            //(max-min)+min
            box.alpha = Math.random() * (1.2 - 0.8) + 0.8;
            //console.log(button.alpha);
            createjs.Ticker.addEventListener("tick",function() {
                box.alpha += rate;
                if(box.alpha >= 1.5 || box.alpha <= 0.5){
                    rate *= -1;
                    box.alpha += rate;
                }
            });
        }

        //プレイヤーの箱、選んでいるならキラキラ
        var you_C_box = new createjs.Shape();
        you_C_box.graphics
            .setStrokeStyle(0)
            .beginFill("rgba(255,100,100,0.8)")
            .drawRect(-matrix_wid/2,-matrix_hei/2,matrix_wid/2,matrix_hei);
        this.addChild(you_C_box);
        you_C_box.visible = false;
        kirakira(you_C_box);
        this.you_C_box = you_C_box;

        var you_D_box = new createjs.Shape();
        you_D_box.graphics
            .setStrokeStyle(0)
            .beginFill("rgba(100,100,255,0.8)")
            .drawRect(0,-matrix_hei/2,matrix_wid/2,matrix_hei);
        this.addChild(you_D_box);
        you_D_box.visible = false;
        kirakira(you_D_box);
        this.you_D_box = you_D_box;


        //相手の箱、
        var cpu_C_box = new createjs.Shape();
        cpu_C_box.graphics
            .setStrokeStyle(0)
            .beginFill("rgba(255,100,100,0.6)")
            .drawRect(-matrix_wid/2,-matrix_hei/2,matrix_wid,matrix_hei/2);
        this.addChild(cpu_C_box);
        cpu_C_box.visible = false;
        //kirakira(cpu_C_box);
        this.cpu_C_box = cpu_C_box;

        var cpu_D_box = new createjs.Shape();
        cpu_D_box.graphics
            .setStrokeStyle(0)
            .beginFill("rgba(100,100,255,0.6)")
            .drawRect(-matrix_wid/2,0,matrix_wid,matrix_hei/2);
        this.addChild(cpu_D_box);
        cpu_D_box.visible = false;
        //kirakira(cpu_D_box);
        this.cpu_D_box = cpu_D_box;


        //選んでない方を白くする箱を返す
        function makeWhiteBox(x,y,wid,hei){
            var white_box = new createjs.Shape();
            white_box.graphics
                .setStrokeStyle(0)
                .beginFill("rgba(255,255,255,1.0)")
                .drawRect(x,y,wid,hei);
            white_box.visible = false;

            return white_box;

        }

        var you_C_white_box = makeWhiteBox(0,-matrix_hei/2,matrix_wid/2,matrix_hei);
        this.addChild(you_C_white_box);
        this.you_C_white_box = you_C_white_box;

        var you_D_white_box = makeWhiteBox(-matrix_wid/2,-matrix_hei/2,matrix_wid/2,matrix_hei);
        this.addChild(you_D_white_box);
        this.you_D_white_box = you_D_white_box;

        var cpu_C_white_box = makeWhiteBox(-matrix_wid/2,0,matrix_wid,matrix_hei/2);
        this.addChild(cpu_C_white_box);
        this.cpu_C_white_box = cpu_C_white_box;

        var cpu_D_white_box = makeWhiteBox(-matrix_wid/2,-matrix_hei/2,matrix_wid,matrix_hei/2);
        this.addChild(cpu_D_white_box);
        this.cpu_D_white_box = cpu_D_white_box;


        var x_e = 0;
        var y_e = 0;

        for(var i=0;i<2;i++){
            for(var j=0;j<2;j++){
                var bod = new createjs.Shape();
                bod.graphics
                    .setStrokeStyle(1*matrix_scale)
                    .beginStroke("gray")
                    .drawRect(x_e-matrix_wid/2,y_e-matrix_hei/2,matrix_wid/2,matrix_hei/2);
                this.addChild(bod);

                x_e += matrix_wid/2;
            
            }
            x_e = 0;
            y_e = matrix_hei/2;
        }

        x_e = 0;
        y_e = 0;

        function makeBox(x_e,y_e,color) {
            var box = new BoxRewards(color);
            box.x = x_e-matrix_wid/2;
            box.y = y_e-matrix_hei/2;
            return box;
            
        }

        //上側
        var box_0 = makeBox(x_e,y_e,youColor);
        x_e += box_wid;
        this.addChild(box_0);
        this.box_0 = box_0;

        var box_1 = makeBox(x_e,y_e,cpuColor);
        x_e += box_wid;
        this.addChild(box_1);
        this.box_1 = box_1;

        var box_2 = makeBox(x_e,y_e,youColor);
        x_e += box_wid;
        this.addChild(box_2);
        this.box_2 = box_2;

        var box_3 = makeBox(x_e,y_e,cpuColor);
        x_e += box_wid;
        this.addChild(box_3);
        this.box_3 = box_3;


        //相手が選んだボタンの表示
        function cpuButton(plusText="def",textColor="white",fillColor=button_fill_color){
            //格納する箱
            var obj = new createjs.Container();
            //背景の座布団
            var bg = new createjs.Shape();
            bg.graphics
                .setStrokeStyle(1)
                .beginStroke("black")
                .beginFill(fillColor)
                .drawRoundRect(-box_wid/2*0.8,-box_hei/2*0.8,box_wid*0.8,box_hei*0.8,10);
            obj.addChild(bg);
            //テキスト
            var text = new createjs.Text();
            text.text = plusText;
            var fontSize = box_wid*0.8;
            text.font = String(fontSize)+"px sans-serif";
            text.color = textColor;
            text.textAlign = "center";
            text.textBaseline = "bottom";
            text.y = fontSize/2;
            obj.addChild(text);

            return obj;
            
        }

        //相手側のテキスト、と示す
        var text_couterpart = new createjs.Text();
        text_couterpart.text = "counterpart";
        text_couterpart.font = String(matrix_fontSize)+"px sans-serif";
        text_couterpart.color = "black";
        text_couterpart.textAlign = "center";
        text_couterpart.textBaseline = "bottom";
        text_couterpart.x = x_e+10+box_wid/2-matrix_wid/2;
        text_couterpart.y = -20-matrix_hei/2;
        //this.addChild(text_couterpart);

        //相手の選んだボタンC、アクティブの時
        var cpu_button_C_active = cpuButton("C","white",button_C_fillColor);
        this.addChild(cpu_button_C_active);
        cpu_button_C_active.x = x_e+10+box_wid/2-matrix_wid/2;
        cpu_button_C_active.y = y_e+box_hei/2-matrix_hei/2;
        //選ばれなかった場合のグレー
        var cpu_button_C_gray = cpuButton("C","white","gray");
        this.addChild(cpu_button_C_gray);
        cpu_button_C_gray.x = cpu_button_C_active.x;
        cpu_button_C_gray.y = cpu_button_C_active.y;
        cpu_button_C_gray.visible = false;
        this.cpu_button_C_gray = cpu_button_C_gray;


        //下側
        x_e = 0;
        y_e += box_hei;
        var box_4 = makeBox(x_e,y_e,youColor);
        x_e += box_wid;
        this.addChild(box_4);
        this.box_4 = box_4;

        var box_5 = makeBox(x_e,y_e,cpuColor);
        x_e += box_wid;
        this.addChild(box_5);
        this.box_5 = box_5;

        var box_6 = makeBox(x_e,y_e,youColor);
        x_e += box_wid;
        this.addChild(box_6);
        this.box_6 = box_6;

        var box_7 = makeBox(x_e,y_e,cpuColor);
        x_e += box_wid;
        this.addChild(box_7);
        this.box_7 = box_7;

        //相手の選んだボタンD、アクティブ
        var cpu_button_D_active = cpuButton("D","white",button_D_fillColor);
        this.addChild(cpu_button_D_active);
        cpu_button_D_active.x = x_e+10+box_wid/2-matrix_wid/2;
        cpu_button_D_active.y = y_e+box_hei/2-matrix_hei/2;
        this.cpu_button_D_active = cpu_button_D_active;
        //選ばれなかった場合のグレー
        var cpu_button_D_gray = cpuButton("D","white","gray");
        this.addChild(cpu_button_D_gray);
        cpu_button_D_gray.x = cpu_button_D_active.x;
        cpu_button_D_gray.y = cpu_button_D_active.y;
        cpu_button_D_gray.visible = false;
        this.cpu_button_D_gray = cpu_button_D_gray;

        //数値を設定
        this.setValue();

        //小さく
        this.scaleX = 1/matrix_scale;
        this.scaleY = 1/matrix_scale;

    }

    //数値を設定
    setValue(){
        this.box_0.setValue(a);
        this.box_1.setValue(b);
        this.box_2.setValue(c);
        this.box_3.setValue(d);
        this.box_4.setValue(e);
        this.box_5.setValue(f);
        this.box_6.setValue(g);
        this.box_7.setValue(h);
    }

    //Cボックスを目立たせる
    C_kirakira(C_f=true){
        this.you_C_box.visible = C_f;
        this.you_C_white_box.visible = C_f;
        this.you_D_box.visible = !C_f;
        this.you_D_white_box.visible = !C_f;
    }

    //Dボックスを目立たせる
    D_kirakira(){
        this.C_kirakira(false)
        /*
        this.you_D_box.visible = true;
        this.you_D_white_box.visible = true;
        this.you_C_box.visible = false;
        this.you_C_white_box.visible = false;
        */
    }

    //キラキラを止める
    stop_kirakira(){
        this.you_C_box.visible = false;
        this.you_C_white_box.visible = false;
        this.you_D_box.visible = false;
        this.you_D_white_box.visible = false;
        this.cpu_C_box.visible = false;
        this.cpu_C_white_box.visible = false;
        this.cpu_D_box.visible = false;
        this.cpu_D_white_box.visible = false;
    }

    //相手がCを選んだら、そちらを見せる
    cpu_kirakira(C_f=true){
        this.cpu_C_box.visible = C_f;
        this.cpu_C_white_box.visible = C_f;
        this.cpu_D_box.visible = !C_f;
        this.cpu_D_white_box.visible = !C_f;
    }

    //相手の選んでいないボタンをグレーアウト
    cpuButton_gray(C_f=false,default_f=!C_f){
        this.cpu_button_C_gray.visible = !C_f;
        this.cpu_button_D_gray.visible = !default_f;

    }

}


//ボックスのプロパティ
{
    var box_space = box_wid * 0.2;
    var box_text_size = matrix_hei / 4;
}

//表示するボックスのclass
class BoxRewards extends createjs.Container {

    constructor(fillColor="red"){
        super();

        //箱
        var box = new createjs.Shape();
        box.graphics
            .setStrokeStyle(1*matrix_scale)
            .beginStroke("rgba(0,0,0,0.8)")
            .beginFill(fillColor)
            .drawRoundRect(box_space/2,box_space/2,box_wid-box_space,box_hei-box_space,10*matrix_scale);
        this.addChild(box);

        //数値
        var text = new createjs.Text("","","");
        text.text = "de";
        text.font = String(box_text_size)+"px sans-serif";
        text.color = "black";
        text.textAlign = "center";
        text.textBaseline = "bottom";
        text.x = box_wid / 2;
        text.y = box_hei / 2 + box_text_size / 2;
        this.addChild(text);
        this.text = text;

        this.setValue();
    }

    setValue(a=0){
        this.text.text = String(a);
    }
}


//得点画像のプロパティ
{
    var score_size = 50;
    var score_spa = 5;

    var deer_pro = ["./images/deer.png",50,3,"rgba(250,100,100,0.9)"];
    var rabbit_pro = ["./images/rabbit.png",35,2,"green"];
    var rat_pro = ["./images/rat.png",30,1,"yellow"];
    var score_list = [deer_pro,rabbit_pro,rat_pro];
}

//ポップアップの得点画像のclass
class ScoreImage extends createjs.Container {

    constructor(wid,image_src,size,scoreText,fillColor,howmany=1){
        super();

        this.wid = wid;
        var score_s = new createjs.Container();
        this.addChild(score_s);
        //score_s.x = 0;

        var image = new Image();
        image.src = image_src;
        image.onload = () => {

            for(var i=0;i<howmany;i++){
                wid += score_spa;

                var score_boards = new createjs.Container();
                this.addChild(score_boards);
                score_boards.x = wid;

                var circle_size = size / 2;
                var circle = new createjs.Shape();
                circle.graphics
                    .setStrokeStyle(1)
                    .beginStroke("black")
                    .beginFill("rgba(255,255,255,0.8)")
                    .drawCircle(0,0,circle_size);
                score_boards.addChild(circle);
                circle.x = size/2;

                var animalImage = new createjs.Bitmap(image);

                animalImage.scaleX = size / animalImage.getBounds().width;
                animalImage.scaleY = animalImage.scaleX;

                animalImage.x = circle.x-size/2;
                animalImage.y = -size/2;

                score_boards.addChild(animalImage)

                var ten_size = 10;
                var ten = new createjs.Shape();
                ten.graphics
                    .setStrokeStyle(1)
                    .beginStroke("gray")
                    .beginFill(fillColor)
                    .drawCircle(0,0,ten_size)
                score_boards.addChild(ten);
                ten.x = circle.x-size*0.4;
                ten.y = size*0.4;

                var label = new createjs.Text("", "20px sans-serif", "black");
                label.text = String(scoreText);
                label.x = ten.x;
                label.y = ten.y;
                label.textAlign = "center";
                label.textBaseline = "middle";
                score_boards.addChild(label);

                wid += size+score_spa;

            }
        
        }
    }

}

//得点から画像の表示数を割り出し、リストを返す関数
function toScoreList(score) {
    var list = [];
    var bo = 0;

    function checking(value) {
        bo = 0;

        bo = parseInt(score / value);
        score = parseInt(score % value);
        
        list.push(bo);
    }

    checking(3);
    checking(2);
    checking(1);

    //console.log(list);

    return list;
}

//得点ボードのclass
class ScoreBorad extends createjs.Container {

    constructor(list=[1,2,3],scoreList=score_list){
        super();

        this.scoreList = scoreList;

        var score = new createjs.Container();
        this.addChild(score);
        this.score = score;

        var wid = 0;

        for(var i = 0;i<scoreList.length;i++){
            var score_obj = new ScoreImage(wid,scoreList[i][0],scoreList[i][1],scoreList[i][2],scoreList[i][3],list[i]);
            score.addChild(score_obj);
            wid += (scoreList[i][1] + score_spa * 2 ) * list[i];
            score_obj.x = wid;

        }

        score.x = 0;

        var box = new createjs.Shape();
        if(debug)this.addChild(box);
        this.box = box;
        box.graphics
            .setStrokeStyle(1)
            .beginStroke("black")
            .drawRect(-wid/2,-35,wid,70);

        //this.setScore(toScoreList(5));

    }

    setScore(list=[1,2,3]){
        var scoreList = this.scoreList;
        this.removeAllChildren();
        
        var score = new createjs.Container();
        this.addChild(score);
        this.score = score;

        var wid = 0;

        for(var i = 0;i<scoreList.length;i++){
            var score_obj = new ScoreImage(wid,scoreList[i][0],scoreList[i][1],scoreList[i][2],scoreList[i][3],list[i]);
            score.addChild(score_obj);
            wid += (scoreList[i][1] + score_spa * 2 ) * list[i];

        }

        score.x = -wid/2;

        var box = new createjs.Shape();
        //this.addChild(box);
        this.box = box;
        box.graphics
            .setStrokeStyle(1)
            .beginStroke("black")
            .drawRect(-wid/2,-35,wid,70);
    }
}


//RewardBoxのプロパティ
{
    //表示領域
    var rb_wid = 80;
    var rb_hei = 60;
    var rb_strokeColor = "rgba(0,0,0,0.7)";
    var rb_fillColor = "rgba(250,250,150,0.5)";
    var rb_round = 0;

    //獲得点のテキスト
    var rb_font_size = 40;
    var rb_font = String(rb_font_size)+"px sans-serif";
    var rb_text_color = "";

    //名前
    var rb_name_font_size = 15;
    var rb_name_font = String(rb_name_font_size)+"px sans-serif";
    var rb_name_color = "";

    //色
    var rb_over_fillColor = "rgba(255,100,100,0.8)";
    var rb_down_fillColor = "rgba(100,100,255,0.8)";



}

//獲得した得点のボックス
class RewardBox extends createjs.Container{

    constructor(Name="default",fillColor=rb_fillColor,strokeColor=rb_strokeColor){
        super();

        game_stage.addChild(this);

        //表示領域
        var box = new createjs.Shape();
        box.graphics
            .setStrokeStyle(1)
            .beginStroke(strokeColor)
            .beginFill(fillColor)
            .drawRoundRect(-rb_wid/2,-rb_hei/2,rb_wid,rb_hei,rb_round);
        this.addChild(box);

        //獲得しているスコアのテキスト
        var text = new createjs.Text();
        text.text = "0";
        text.font = rb_font;
        text.color = rb_text_color;
        text.textAlign = "center";
        text.textBaseline = "bottom";
        text.y = rb_font_size / 2;
        this.addChild(text);
        this.text = text;

        //このオブジェクトの名前
        var name = new createjs.Text();
        name.text = Name;
        name.font = rb_name_font;
        name.color = rb_name_color;
        name.textAlign = "center";
        name.textBaseline = "bottom";
        name.x = 0;
        name.y = -rb_hei-wgs_hei*1.2;

        var name_cover = new createjs.Shape();
        var cover_wid = rb_name_font_size * 5;
        name_cover.graphics
            .setStrokeStyle(0)
            .beginFill(fillColor)
            .drawRoundRect(-cover_wid/2,-rb_name_font_size,cover_wid,rb_name_font_size*1.5,10);
        name_cover.x = name.x;
        name_cover.y = name.y;
        this.addChild(name_cover)

        this.addChild(name);


        //得られる得点の表示、上側
        var will_get_over = new WillGetScore(rb_over_fillColor);
        will_get_over.x = 0;
        will_get_over.y = card_and_reward_over_Y;
        this.addChild(will_get_over);
        this.will_get_over = will_get_over;

        //得られる得点の表示、下側
        var will_get_down = new WillGetScore(rb_down_fillColor);
        will_get_down.x = 0;
        will_get_down.y = card_and_reward_down_Y;
        this.addChild(will_get_down);
        this.will_get_down = will_get_down;

        this.setTotalReward(0);
        this.setWillGetReward(0,0);

    }

    //上下のいずれかを強調（結果表示）、デフォルトは上を残す
    gotWillVisible(default_f=true,agent_f=true){
        if(default_f){
            this.will_get_over.visible = true;
            this.will_get_down.visible = true;
        }else{
            if(agent_f){
                this.will_get_over.visible = true;
                this.will_get_down.visible = false; 
            }else{
                this.will_get_over.visible = false;
                this.will_get_down.visible = true;
            }
        }

    }

    //総得点を更新
    setTotalReward(total_reward) {
        this.text.text = String(total_reward);
    }

    //上下の得点を更新
    setWillGetReward(over_value,down_value) {
        this.will_get_over.setWillGetReward(over_value);
        this.will_get_down.setWillGetReward(down_value);

    }
}

//WillGetScoreのプロパティ
{
    var wgs_wid = 80;
    var wgs_hei = 50;

    var wgs_text_font_size = wgs_hei * 0.8;
}

//得られる得点の表示のclass
class WillGetScore extends createjs.Container {

    constructor(fillColor="red"){
        super();

        //座布団
        var bg = new createjs.Shape();
        bg.graphics
            .setStrokeStyle(1)
            .beginStroke(fillColor)
            .drawRect(-wgs_wid/2,-wgs_hei/2,wgs_wid,wgs_hei);
        this.addChild(bg);

        //得点テキスト
        var text = new createjs.Text();
        text.text = "de";
        text.font = String(wgs_text_font_size)+"px fantasy";
        text.color = fillColor;
        text.textAlign = "center";
        text.textBaseline = "bottom";
        text.y = wgs_text_font_size / 2;
        this.addChild(text);
        this.text = text;

    }

    setWillGetReward(value) {
        var plus_minus_text;
        if(value>0){
            plus_minus_text = "+";
        }else if(value<0){
            plus_minus_text = "-";
        }else{
            plus_minus_text = "";
        }
        this.text.text = plus_minus_text + String(value);

    }
}

//ボタンのプロパティ
{
//ボタンのサイズ
var button_wid = 120;
var button_hei = 70;
var button_round = 30;
//ボタンの色
var button_stroke_size = 1;
var button_stroke_color = "black";
var button_fill_color = "rgba(255,0,255,0.5)";
//ボタンのテキスト
var button_text_fontsize = button_hei / 2;
var button_text = "default";
var button_text_font = String(button_text_fontsize)+"px sans-serif";
var button_text_color = "black";
var button_text_textAlign = "center";
var button_text_textBaseline = "bottom";
var button_text_x = 0;
var button_text_y = button_text_fontsize/2;

}

//ボタンのclass
class ChoiceButton extends createjs.Container {

    constructor(Text=button_text,button_textColor=button_text_color,button_fillColor=button_fill_color){
        super();

        //自分をステージに追加
        game_stage.addChild(this);

        //見た目を表示
        var button = new createjs.Shape();
        button.graphics
            .setStrokeStyle(button_stroke_size)
            .beginStroke(button_stroke_color)
            .beginFill(button_fillColor)
            .drawRoundRect(-button_wid/2,-button_hei/2,button_wid,button_hei,button_round);
        this.addChild(button);

        //「選択（CかD）」のテキストを表示
        var text = new createjs.Text("", "", "");
        text.text = Text;
        text.font = button_text_font;
        text.color = button_textColor;
        //中心にセット
        text.x = button_text_x;
        text.y = button_text_y;
        text.textAlign = button_text_textAlign;
        text.textBaseline = button_text_textBaseline;
        this.addChild(text);

        //リスナーを付ける
        this.listenerThis();

        var rate = 1/60 * 0.5;
        //(max-min)+min
        button.alpha = Math.random() * (1.2 - 0.8) + 0.8;
        //console.log(button.alpha);
        createjs.Ticker.addEventListener("tick",function() {
            button.alpha += rate;
            if(button.alpha >= 1.2 || button.alpha <= 0.8){
                rate *= -1;
            }
        });

    }

    listenerThis(){
        var listener = this;

        this.addEventListener("mousedown",handleMouseDown);
        this.addEventListener("click",handleClick);
        this.addEventListener("mouseover",handleMouseOver);
        this.addEventListener("mouseout", handleMouseOut);

        function handleMouseDown() {
            listener.scaleX = 1.1;
            listener.scaleY = 1.1;
            
        }

        function handleClick() {
            listener.scaleX = 1.2;
            listener.scaleY = 1.2;
            
        }

        function handleMouseOver() {
            listener.scaleX = 1.2;
            listener.scaleY = 1.2;
            
        }

        function handleMouseOut() {
            listener.scaleX = 1.0;
            listener.scaleY = 1.0;
            
        }

    }

}




//いい例のボタン
class MyButton extends createjs.Container {

    constructor(){
        super();

        var btnW = 240; // ボタンの横幅
        var btnH = 50; // ボタンの高さ

        // 座布団を作成
        var bg = new createjs.Shape();
        bg.graphics
              .setStrokeStyle(1)
              .beginStroke("#563d7c")
              .beginFill("white")
              .drawRoundRect(0, 0, btnW, btnH, 4);
        // 座布団のグラフィックを描く (省略)
        this.addChild(bg);

        // ラベルを作成
        var label = new createjs.Text("Button", "24px sans-serif", "#563d7c");
        label.x = btnW / 2;
        label.y = btnH / 2;
        label.textAlign = "center";
        label.textBaseline = "middle";
        // ラベルの配置場所を調整 (省略)
        this.addChild(label);

        // イベントを登録
        this.addEventListener("click", handleClick);
        function handleClick(event) {
            // クリックされた時の処理を記述
            alert("クリックされました。");
        }
    }
}

//継承
class MyStar extends createjs.Shape {
    constructor(){
        super();

        // 円を作成します
        this.graphics.beginStroke("Purple");// 線の色を指定
        this.graphics.setStrokeStyle(5);// 線の幅を指定
        this.graphics.drawCircle(0, 0, 150); // 半径150pxの円を記述
        this.graphics.endStroke();

        // 多角形を作成します
        this.graphics.beginFill('Purple'); // 塗りの色を指定
        this.graphics.drawPolyStar(0, 0, 150, 5, 0.6, -90); // 半径150pxの星を記述
        this.graphics.endFill();
    }
}

/** コンテナーを継承したサブクラスです。 */
class MyContainer extends createjs.Container {
    constructor() {
        super();
  
        // 円を作成します
        var circle = new createjs.Shape();
        circle.graphics.beginStroke("DarkRed");// 線の色を指定
        circle.graphics.setStrokeStyle(5);// 線の幅を指定
        circle.graphics.drawCircle(0, 0, 150); // 50pxの星を記述
        this.addChild(circle); // 表示リストに追加
  
        // 多角形を作成します
        var poly = new createjs.Shape();
        poly.graphics.beginFill('DarkRed'); // 赤色で描画するように設定
        poly.graphics.drawPolyStar(0, 0, 150, 5, 0.6, -90); // 150pxの星を記述
        this.addChild(poly); // 表示リストに追加
    }
}

